create function week_bounds(p_tz text)
    returns TABLE(week_start_utc timestamp with time zone, week_end_utc timestamp with time zone)
    stable
    language sql
as
$$
    SELECT
    (date_trunc('week', (now() AT TIME ZONE p_tz)) AT TIME ZONE p_tz) AS week_start_utc,
    ((date_trunc('week', (now() AT TIME ZONE p_tz)) + interval '7 days') AT TIME ZONE p_tz) AS week_end_utc;
$$;

alter function week_bounds(text) owner to admin;

