create function weekly_sessions(p_user_id integer, p_tz text, p_media_type text)
    returns TABLE(runtime integer, user_id integer, activity_type text, start_time_utc timestamp with time zone)
    stable
    language sql
as
$$

    WITH b AS (SELECT * FROM public.week_bounds(p_tz)),

    sessions AS (
    SELECT
        mi.runtime,
        a."userId",
        a."activityType",
        a."updatedAt" - ( mi.runtime * interval '1 minute') as start_time_utc
    
    FROM activity_log AS a
    JOIN media_info AS mi ON a."mediaInfoId" = mi.id
    WHERE a."userId" = p_user_id
    AND a."activityType" = 'watch'
    AND mi."mediaType" = p_media_type)

    SELECT s.*
    FROM sessions AS s
    CROSS JOIN b
    WHERE s.start_time_utc >= b.week_start_utc
    AND s.start_time_utc < b.week_end_utc
    $$;

alter function weekly_sessions(integer, text, text) owner to admin;

